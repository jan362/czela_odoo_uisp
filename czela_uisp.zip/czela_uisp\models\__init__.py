# -*- coding: utf-8 -*-

from . import uisp_config
from . import uisp_device
from . import uisp_site
from . import uisp_sync
from . import res_partner
